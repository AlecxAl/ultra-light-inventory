const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const db = new sqlite3.Database('./inventory.db');

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS inventory (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER)");
});

app.use(bodyParser.json());
app.use(express.static('public'));

app.get('/api/items', (req, res) => {
    db.all("SELECT * FROM inventory", [], (err, rows) => {
        res.json(rows);
    });
});

app.post('/api/items', (req, res) => {
    const { name, quantity } = req.body;
    db.run("INSERT INTO inventory (name, quantity) VALUES (?, ?)", [name, quantity], function(err) {
        if (!err) {
            io.emit('update');
            res.json({ id: this.lastID, name, quantity });
        }
    });
});

app.put('/api/items/:id', (req, res) => {
    const { id } = req.params;
    const { quantity } = req.body;
    db.run("UPDATE inventory SET quantity = ? WHERE id = ?", [quantity, id], function(err) {
        if (!err) {
            io.emit('update');
            res.json({ id, quantity });
        }
    });
});

io.on('connection', (socket) => {
    console.log('a user connected');
});

server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
